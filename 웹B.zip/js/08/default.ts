import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Search } from 'src/app/core/search';
import { MypageTranslationService } from 'src/app/services/mypage/translation.service';
import { SearchService } from 'src/app/services/search.service';
import { SnsShareService } from 'src/app/services/sns-share.service';
declare var page: any;
declare var $: any;
declare var AOS: any;
declare var Swiper: any;


// 번역요청
@Component({
    templateUrl: './campaign756.component.html',
    styleUrls: ['./campaign756.component.css']
})
export class SupportCampaign756Component implements OnInit {

    id = 756;
    categoryId = 10;

    showShare = false;


    constructor(

        private snsService: SnsShareService,

    ) {

    }
    ngOnInit() {
        setTimeout(function(){
            // videoUI
            var supportVideoArea = $('.supportWrap .videoArea');

            if(supportVideoArea.length <= 0){
                return;
            }

            $(window).on('scroll' , function() {
                var sct = $(this).scrollTop();
                if(sct >=supportVideoArea.offset().top + supportVideoArea.height() + 200){
                    supportVideoArea.find('.videoBoxArea').addClass('fixed');
                }
                else{
                    supportVideoArea.find('.videoBoxArea').removeClass('fixed');
                }

                if($('#footer').length > 0){
                    if($(window).scrollTop() >= $(document).height() - $(window).height() - $('#footer').height()){
                        supportVideoArea.find('.videoBoxArea').addClass('nofixed');
                    }
                    else{
                        supportVideoArea.find('.videoBoxArea').removeClass('nofixed');
                    }
                }
            });

            supportVideoArea.find('.btnVideoClose').on('click' , function(e){
                e.preventDefault();

                supportVideoArea.find('.videoBoxArea').removeClass('fixed');
                $(window).unbind();
                return false;
            });

            // sectionUI
            var sectionWrap  = $('.supportWrap');
                
            if(sectionWrap.length <= 0){
                return;
            }

            // 섹션 스크롤 이벤트
            $(window).off('scroll.eventScroll').on('scroll.eventScroll', function(){
                var _this = $(this);
                var sct = _this.scrollTop() + window.innerHeight;

                sectionWrap.find('.uiMotion').each(function(idx, obj){
									if(sct > $(obj).offset().top + 200){
						
										$(obj).addClass('overlap');
									}
									else{
										$(obj).removeClass('overlap');
									}
								});
            }).trigger('scroll.eventScroll');
        },500);
    }

    share(flatform, title, description, image) {
        let redirect = window.location.href;
        let mobileRedirect = window.location.href;
        this.snsService.share(flatform, title, description, image, redirect, mobileRedirect);
    }

}